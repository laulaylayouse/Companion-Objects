package com.example.companion_objects_app_laila

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.companionobjectsapp.Time

class MainActivity : AppCompatActivity() {

    lateinit var Edit_Text: EditText
    lateinit var Button_change: Button
    lateinit var Constraint_Layout: ConstraintLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        Edit_Text = findViewById(R.id.Edit_Text)
        Button_change = findViewById(R.id.Button_change)
        Constraint_Layout = findViewById(R.id.Constraint_Layout)

        Button_change.setOnClickListener {
            val userInput = Edit_Text.text.toString()
            Edit_Text.setText("")
            val time = Time.time
            if (userInput.equals("Day", true)) {
                time.changeBackground(Constraint_Layout, true)
                Edit_Text.setTextColor(Color.BLACK)
            } else if (userInput.equals("Night", true)) {
                time.changeBackground(Constraint_Layout, false)
                Edit_Text.setTextColor(Color.WHITE)

            } else {
                Toast.makeText(this, "Please Enter Only Day or Night..", Toast.LENGTH_SHORT).show()
            }

        }
    }
}