package com.example.companionobjectsapp

import android.view.View
import com.example.companion_objects_app_laila.R

class Time {
    companion object time {

        fun changeBackground(view: View, check: Boolean) {
            when (check) {
                true -> {
                    view.setBackgroundResource(R.drawable.day1)
                }
                false -> {
                    view.setBackgroundResource(R.drawable.night)
                }
            }
        }
    }

}

